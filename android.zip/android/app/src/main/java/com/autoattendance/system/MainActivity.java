package com.autoattendance.system;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        registerPlugin(DeviceCredentialPlugin.class);
    }
}